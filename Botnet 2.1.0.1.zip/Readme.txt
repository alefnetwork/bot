Run this File on Safe Place Like VM/Sandboxie.
Use It Only For Educational Purpose!!

For More Hacking Stuffs Join @XploitWizer on Telegram!

https://t.me/XploitWizer

By @SHADOW2639 :)