<?php if(!defined('__CP__'))die();
define('LNG_STATS',                   'Общая статистика');
define('LNG_STATS_TOTAL_INFO',        'Общая информация');
define('LNG_STATS_TOTAL_REPORTS',     'Всего отчетов в базе данных:');
define('LNG_STATS_TOTAL_BOTS24',      'Всего активных ботов за 24 часа:');
define('LNG_STATS_TOTAL_BOTS',        'Всего ботов:');
define('LNG_STATS_TOTAL_MIN_VERSION', 'Минимальная версия бота:');
define('LNG_STATS_TOTAL_MAX_VERSION', 'Максимальная версия бота:');
define('LNG_STATS_FIRST_BOT',         'Время первой активности');
define('LNG_STATS_RESET_NEWBOTS',     'Обнулить &quot;Новые боты&quot;');
define('LNG_STATS_RESET_NEWBOTS_Q',   'Вы действительно хотите обнулить список новых ботов?');
define('LNG_STATS_COUNTRYLIST_EMPTY', '-- Пусто --');
define('LNG_STATS_COLUMN_NEWBOTS',    'Новые боты (%s)');
define('LNG_STATS_COLUMN_ONLINEBOTS', 'Боты в онлайне (%s)');
define('LNG_STATS_BOTNET',            'Текущий ботнет:');
define('LNG_STATS_BOTNET_ACTIONS',    'Действия:');
?>