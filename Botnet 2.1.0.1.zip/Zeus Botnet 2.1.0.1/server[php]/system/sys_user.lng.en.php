<?php if(!defined('__CP__'))die();
define('LNG_SYS', 'User');

define('LNG_SYS_MAIN',     'Main options');
define('LNG_SYS_LANGUAGE', 'Language:');

define('LNG_SYS_SS',         'Screenshot options');
define('LNG_SYS_SS_FORMAT',  'Format:');
define('LNG_SYS_SS_QUALITY', 'Quality:');

define('LNG_SYS_PASSWORD',      'Change password');
define('LNG_SYS_PASSWORD_OLD',  'Current password:');
define('LNG_SYS_PASSWORD_NEW1', 'New password:');
define('LNG_SYS_PASSWORD_NEW2', 'Confirm new password:');
define('LNG_SYS_PASSWORD_E1',   'Bad old password.');
define('LNG_SYS_PASSWORD_E2',   'New password and confirmation do not match.');
define('LNG_SYS_PASSWORD_E3',   'Password should have minimum length of %u and a maximum of %u characters.');

define('LNG_SYS_SAVE', 'Save');

define('LNG_SYS_UPDATED', 'Options successfully updated.');
?>